﻿CREATE DATABASE LibraryDB;
GO
USE LibraryDB;
GO

CREATE TABLE Categories (
    CategoryID INT IDENTITY(1,1) PRIMARY KEY,
    CategoryName NVARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE Books (
    BookID INT IDENTITY(1,1) PRIMARY KEY,
    ISBN VARCHAR(20) NOT NULL UNIQUE,
    Title NVARCHAR(250) NOT NULL,
    Publisher NVARCHAR(150) NULL,
    YearPublished SMALLINT NULL CHECK (YearPublished >= 1000 AND YearPublished <= 9999),
    CopiesAvailable INT NOT NULL CONSTRAINT CK_Books_Copies CHECK (CopiesAvailable >= 0),
    CategoryID INT NULL,
    CONSTRAINT FK_Books_Categories FOREIGN KEY (CategoryID) REFERENCES Categories(CategoryID)
);

CREATE TABLE Members (
    MemberID INT IDENTITY(1,1) PRIMARY KEY,
    FullName NVARCHAR(200) NOT NULL,
    Email NVARCHAR(150) NULL,
    Phone VARCHAR(20) NULL,
    Address NVARCHAR(300) NULL,
    JoinDate DATE NOT NULL DEFAULT (GETDATE())
);

CREATE TABLE Loans (
    LoanID INT IDENTITY(1,1) PRIMARY KEY,
    BookID INT NOT NULL,
    MemberID INT NOT NULL,
    LoanDate DATE NOT NULL DEFAULT (GETDATE()),
    DueDate DATE NOT NULL,
    ReturnDate DATE NULL,
    Status NVARCHAR(20) NOT NULL DEFAULT ('Borrowed'),
    CONSTRAINT FK_Loans_Books FOREIGN KEY (BookID) REFERENCES Books(BookID),
    CONSTRAINT FK_Loans_Members FOREIGN KEY (MemberID) REFERENCES Members(MemberID),
    CONSTRAINT CHK_DueDate CHECK (DueDate >= LoanDate)
);

CREATE TABLE Authors (
    AuthorID INT IDENTITY(1,1) PRIMARY KEY,
    Name NVARCHAR(200) NOT NULL
);

CREATE TABLE BookAuthors (
    BookID INT NOT NULL,
    AuthorID INT NOT NULL,
    PRIMARY KEY (BookID, AuthorID),
    CONSTRAINT FK_BA_Books FOREIGN KEY (BookID) REFERENCES Books(BookID),
    CONSTRAINT FK_BA_Authors FOREIGN KEY (AuthorID) REFERENCES Authors(AuthorID)
);

CREATE INDEX IX_Books_Title ON Books(Title);
CREATE INDEX IX_Members_FullName ON Members(FullName);

INSERT INTO Categories (CategoryName) VALUES (N'Khoa học máy tính'), (N'Văn học'), (N'Tiểu thuyết');
INSERT INTO Books (ISBN, Title, Publisher, YearPublished, CopiesAvailable, CategoryID)
VALUES ('978-0143127796', N'Clean Code', N'Prentice Hall', 2008, 5, 1),
       ('978-0132350884', N'Clean Architecture', N'Prentice Hall', 2017, 3, 1);
INSERT INTO Members (FullName, Email, Phone, Address) VALUES
       (N'Nguyễn Văn A', 'a@example.com', '0123456789', N'Hà Nội'),
       (N'Trần Thị B', 'b@example.com', '0987654321', N'Hồ Chí Minh');

INSERT INTO Loans (BookID, MemberID, LoanDate, DueDate, Status)
VALUES (1, 1, GETDATE(), DATEADD(day,14,GETDATE()), 'Borrowed');
   
    